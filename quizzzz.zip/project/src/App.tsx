import React, { useState } from 'react';
import { Clock, Trophy, RotateCcw } from 'lucide-react';
import CategorySelection from './components/CategorySelection';
import QuizInterface from './components/QuizInterface';
import ResultsScreen from './components/ResultsScreen';
import { Quiz } from './types/quiz';

function App() {
  const [currentScreen, setCurrentScreen] = useState<'category' | 'quiz' | 'results'>('category');
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const handleQuizStart = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setCurrentScreen('quiz');
    setScore(0);
    setUserAnswers([]);
  };

  const handleQuizComplete = (finalScore: number, answers: number[]) => {
    setScore(finalScore);
    setUserAnswers(answers);
    setCurrentScreen('results');
  };

  const handleRestart = () => {
    setCurrentScreen('category');
    setSelectedQuiz(null);
    setScore(0);
    setUserAnswers([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Trophy className="w-8 h-8 text-yellow-400" />
            <h1 className="text-4xl font-bold text-white">QuizMaster</h1>
          </div>
          <p className="text-blue-200 text-lg">Test your knowledge with interactive quizzes</p>
        </div>

        {/* Screen Content */}
        {currentScreen === 'category' && (
          <CategorySelection onQuizStart={handleQuizStart} />
        )}

        {currentScreen === 'quiz' && selectedQuiz && (
          <QuizInterface 
            quiz={selectedQuiz} 
            onQuizComplete={handleQuizComplete}
          />
        )}

        {currentScreen === 'results' && selectedQuiz && (
          <ResultsScreen 
            quiz={selectedQuiz}
            score={score}
            userAnswers={userAnswers}
            onRestart={handleRestart}
          />
        )}
      </div>
    </div>
  );
}

export default App;