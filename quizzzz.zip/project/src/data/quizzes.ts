import { Quiz } from '../types/quiz';

export const quizzes: Quiz[] = [
  {
    id: 'general-easy',
    title: 'General Knowledge - Easy',
    category: 'General Knowledge',
    difficulty: 'Easy',
    description: 'Test your basic general knowledge with these simple questions.',
    timePerQuestion: 30,
    questions: [
      {
        id: 1,
        question: "What is the capital of France?",
        options: ["London", "Berlin", "Paris", "Madrid"],
        correctAnswer: 2,
        explanation: "Paris has been the capital of France since 508 AD."
      },
      {
        id: 2,
        question: "How many continents are there?",
        options: ["5", "6", "7", "8"],
        correctAnswer: 2,
        explanation: "The seven continents are Africa, Antarctica, Asia, Europe, North America, Australia, and South America."
      },
      {
        id: 3,
        question: "What is the largest ocean on Earth?",
        options: ["Atlantic", "Indian", "Arctic", "Pacific"],
        correctAnswer: 3,
        explanation: "The Pacific Ocean covers about one-third of the Earth's surface."
      },
      {
        id: 4,
        question: "Which planet is known as the Red Planet?",
        options: ["Venus", "Mars", "Jupiter", "Saturn"],
        correctAnswer: 1,
        explanation: "Mars appears red due to iron oxide (rust) on its surface."
      },
      {
        id: 5,
        question: "What is the smallest country in the world?",
        options: ["Monaco", "San Marino", "Vatican City", "Liechtenstein"],
        correctAnswer: 2,
        explanation: "Vatican City is only 0.17 square miles in area."
      }
    ]
  },
  {
    id: 'science-medium',
    title: 'Science - Medium',
    category: 'Science',
    difficulty: 'Medium',
    description: 'Challenge yourself with intermediate science questions.',
    timePerQuestion: 45,
    questions: [
      {
        id: 1,
        question: "What is the chemical symbol for gold?",
        options: ["Go", "Gd", "Au", "Ag"],
        correctAnswer: 2,
        explanation: "Au comes from the Latin word 'aurum' meaning gold."
      },
      {
        id: 2,
        question: "How many bones are in the adult human body?",
        options: ["196", "206", "216", "226"],
        correctAnswer: 1,
        explanation: "Adults have 206 bones, while babies are born with about 270 bones."
      },
      {
        id: 3,
        question: "What is the speed of light in a vacuum?",
        options: ["299,792,458 m/s", "300,000,000 m/s", "299,000,000 m/s", "301,000,000 m/s"],
        correctAnswer: 0,
        explanation: "This is one of the fundamental constants of physics."
      },
      {
        id: 4,
        question: "Which gas makes up about 78% of Earth's atmosphere?",
        options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Argon"],
        correctAnswer: 2,
        explanation: "Nitrogen makes up 78%, while oxygen is about 21%."
      },
      {
        id: 5,
        question: "What is the powerhouse of the cell?",
        options: ["Nucleus", "Ribosome", "Mitochondria", "Endoplasmic Reticulum"],
        correctAnswer: 2,
        explanation: "Mitochondria produce ATP, the energy currency of cells."
      }
    ]
  },
  {
    id: 'history-hard',
    title: 'History - Hard',
    category: 'History',
    difficulty: 'Hard',
    description: 'Test your knowledge of historical events and figures.',
    timePerQuestion: 60,
    questions: [
      {
        id: 1,
        question: "In which year did the Berlin Wall fall?",
        options: ["1987", "1988", "1989", "1990"],
        correctAnswer: 2,
        explanation: "The Berlin Wall fell on November 9, 1989, marking the end of the Cold War era."
      },
      {
        id: 2,
        question: "Who was the first person to walk on the moon?",
        options: ["Buzz Aldrin", "Neil Armstrong", "Michael Collins", "John Glenn"],
        correctAnswer: 1,
        explanation: "Neil Armstrong stepped onto the moon on July 20, 1969."
      },
      {
        id: 3,
        question: "The ancient city of Carthage was located in present-day:",
        options: ["Libya", "Tunisia", "Algeria", "Morocco"],
        correctAnswer: 1,
        explanation: "Carthage was located near present-day Tunis, Tunisia."
      },
      {
        id: 4,
        question: "Which empire was ruled by Justinian I?",
        options: ["Roman Empire", "Byzantine Empire", "Ottoman Empire", "Persian Empire"],
        correctAnswer: 1,
        explanation: "Justinian I ruled the Byzantine Empire from 527 to 565 AD."
      },
      {
        id: 5,
        question: "The Treaty of Westphalia ended which war?",
        options: ["Hundred Years' War", "Thirty Years' War", "Seven Years' War", "War of Spanish Succession"],
        correctAnswer: 1,
        explanation: "The Treaty of Westphalia in 1648 ended the Thirty Years' War."
      }
    ]
  },
  {
    id: 'tech-medium',
    title: 'Technology - Medium',
    category: 'Technology',
    difficulty: 'Medium',
    description: 'Modern technology and computing questions.',
    timePerQuestion: 40,
    questions: [
      {
        id: 1,
        question: "What does CPU stand for?",
        options: ["Computer Processing Unit", "Central Processing Unit", "Core Processing Unit", "Central Program Unit"],
        correctAnswer: 1,
        explanation: "CPU is the main processing component of a computer."
      },
      {
        id: 2,
        question: "Which company developed the React JavaScript library?",
        options: ["Google", "Microsoft", "Facebook", "Apple"],
        correctAnswer: 2,
        explanation: "React was created by Facebook (now Meta) in 2013."
      },
      {
        id: 3,
        question: "What does HTML stand for?",
        options: ["Hypertext Markup Language", "Hyperlink Text Markup Language", "Home Text Markup Language", "Hypertext Modern Language"],
        correctAnswer: 0,
        explanation: "HTML is the standard markup language for web pages."
      },
      {
        id: 4,
        question: "Which programming language was created by Guido van Rossum?",
        options: ["Java", "Python", "JavaScript", "Ruby"],
        correctAnswer: 1,
        explanation: "Python was created by Guido van Rossum and first released in 1991."
      },
      {
        id: 5,
        question: "What does AI stand for?",
        options: ["Automated Intelligence", "Artificial Intelligence", "Advanced Intelligence", "Algorithmic Intelligence"],
        correctAnswer: 1,
        explanation: "AI refers to the simulation of human intelligence in machines."
      }
    ]
  }
];