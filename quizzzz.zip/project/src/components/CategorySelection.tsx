import React from 'react';
import { Play, Clock, Star } from 'lucide-react';
import { Quiz } from '../types/quiz';
import { quizzes } from '../data/quizzes';

interface CategorySelectionProps {
  onQuizStart: (quiz: Quiz) => void;
}

const CategorySelection: React.FC<CategorySelectionProps> = ({ onQuizStart }) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-500 text-white';
      case 'Medium': return 'bg-yellow-500 text-white';
      case 'Hard': return 'bg-red-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getDifficultyStars = (difficulty: string) => {
    const count = difficulty === 'Easy' ? 1 : difficulty === 'Medium' ? 2 : 3;
    return Array.from({ length: 3 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < count ? 'text-yellow-400 fill-current' : 'text-gray-400'}`}
      />
    ));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Choose Your Quiz</h2>
        <p className="text-blue-200">Select a category and difficulty level to get started</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {quizzes.map((quiz) => (
          <div
            key={quiz.id}
            className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold text-white mb-1">{quiz.title}</h3>
                <p className="text-blue-200 text-sm">{quiz.category}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getDifficultyColor(quiz.difficulty)}`}>
                {quiz.difficulty}
              </span>
            </div>

            <p className="text-gray-300 text-sm mb-4">{quiz.description}</p>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4 text-sm text-blue-200">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {quiz.timePerQuestion}s per question
                </div>
                <div className="flex items-center gap-1">
                  {getDifficultyStars(quiz.difficulty)}
                </div>
              </div>
              <span className="text-sm text-gray-400">{quiz.questions.length} questions</span>
            </div>

            <button
              onClick={() => onQuizStart(quiz)}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5" />
              Start Quiz
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategorySelection;