import React from 'react';
import { Trophy, RotateCcw, CheckCircle, XCircle, Star } from 'lucide-react';
import { Quiz } from '../types/quiz';

interface ResultsScreenProps {
  quiz: Quiz;
  score: number;
  userAnswers: number[];
  onRestart: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ quiz, score, userAnswers, onRestart }) => {
  const percentage = Math.round((score / quiz.questions.length) * 100);
  
  const getPerformanceMessage = () => {
    if (percentage >= 90) return { message: "Excellent! Outstanding performance!", color: "text-green-400", stars: 3 };
    if (percentage >= 70) return { message: "Great job! Well done!", color: "text-blue-400", stars: 2 };
    if (percentage >= 50) return { message: "Good effort! Keep practicing!", color: "text-yellow-400", stars: 1 };
    return { message: "Keep studying! You'll do better next time!", color: "text-red-400", stars: 0 };
  };

  const performance = getPerformanceMessage();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Results Header */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Trophy className="w-12 h-12 text-yellow-400" />
          <h2 className="text-4xl font-bold text-white">Quiz Complete!</h2>
        </div>
        
        <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-8 mb-6">
          <h3 className="text-2xl font-bold text-white mb-2">{quiz.title}</h3>
          <div className="flex items-center justify-center gap-2 mb-4">
            {Array.from({ length: 3 }, (_, i) => (
              <Star
                key={i}
                className={`w-6 h-6 ${i < performance.stars ? 'text-yellow-400 fill-current' : 'text-gray-400'}`}
              />
            ))}
          </div>
          
          <div className="text-6xl font-bold text-white mb-2">
            {score}/{quiz.questions.length}
          </div>
          <div className="text-2xl font-semibold mb-2" style={{ color: performance.color.replace('text-', '') }}>
            {percentage}%
          </div>
          <p className={`text-lg ${performance.color}`}>{performance.message}</p>
        </div>

        <button
          onClick={onRestart}
          className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center gap-2 mx-auto"
        >
          <RotateCcw className="w-5 h-5" />
          Take Another Quiz
        </button>
      </div>

      {/* Question Review */}
      <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-6">Question Review</h3>
        
        <div className="space-y-6">
          {quiz.questions.map((question, index) => {
            const userAnswer = userAnswers[index];
            const isCorrect = userAnswer === question.correctAnswer;
            const wasSkipped = userAnswer === -1;

            return (
              <div key={question.id} className="border-b border-white/10 pb-6 last:border-b-0">
                <div className="flex items-start gap-3 mb-3">
                  {isCorrect ? (
                    <CheckCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500 mt-1 flex-shrink-0" />
                  )}
                  <div className="flex-1">
                    <h4 className="text-white font-semibold mb-2">
                      {index + 1}. {question.question}
                    </h4>
                    
                    <div className="grid gap-2 mb-3">
                      {question.options.map((option, optionIndex) => {
                        let optionClass = "p-3 rounded-lg text-sm ";
                        
                        if (optionIndex === question.correctAnswer) {
                          optionClass += "bg-green-500/20 border border-green-500/50 text-green-100";
                        } else if (optionIndex === userAnswer && !isCorrect) {
                          optionClass += "bg-red-500/20 border border-red-500/50 text-red-100";
                        } else {
                          optionClass += "bg-white/5 border border-white/10 text-gray-300";
                        }

                        return (
                          <div key={optionIndex} className={optionClass}>
                            <div className="flex items-center justify-between">
                              <span>{option}</span>
                              {optionIndex === question.correctAnswer && (
                                <span className="text-green-400 text-xs font-semibold">Correct</span>
                              )}
                              {optionIndex === userAnswer && !isCorrect && (
                                <span className="text-red-400 text-xs font-semibold">Your Answer</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {wasSkipped && (
                      <p className="text-yellow-400 text-sm mb-2">⏰ Time ran out - No answer selected</p>
                    )}

                    {question.explanation && (
                      <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                        <p className="text-blue-100 text-sm">{question.explanation}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ResultsScreen;