import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle } from 'lucide-react';
import { Quiz } from '../types/quiz';

interface QuizInterfaceProps {
  quiz: Quiz;
  onQuizComplete: (score: number, answers: number[]) => void;
}

const QuizInterface: React.FC<QuizInterfaceProps> = ({ quiz, onQuizComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(quiz.timePerQuestion);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showFeedback) {
      handleAnswer(null); // Auto-submit when time runs out
    }
  }, [timeLeft, showFeedback]);

  // Reset timer when question changes
  useEffect(() => {
    setTimeLeft(quiz.timePerQuestion);
  }, [currentQuestion, quiz.timePerQuestion]);

  const handleAnswer = (answerIndex: number | null) => {
    setSelectedAnswer(answerIndex);
    setShowFeedback(true);

    const newAnswers = [...userAnswers, answerIndex ?? -1];
    setUserAnswers(newAnswers);

    // Check if answer is correct
    if (answerIndex === quiz.questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    // Move to next question after delay
    setTimeout(() => {
      if (currentQuestion < quiz.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setShowFeedback(false);
      } else {
        // Quiz completed
        const finalScore = answerIndex === quiz.questions[currentQuestion].correctAnswer ? score + 1 : score;
        onQuizComplete(finalScore, newAnswers);
      }
    }, 2000);
  };

  const currentQ = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100;

  return (
    <div className="max-w-3xl mx-auto">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-blue-200 text-sm font-medium">
            Question {currentQuestion + 1} of {quiz.questions.length}
          </span>
          <div className="flex items-center gap-2 text-blue-200">
            <Clock className="w-4 h-4" />
            <span className={`font-bold ${timeLeft <= 10 ? 'text-red-400' : ''}`}>
              {timeLeft}s
            </span>
          </div>
        </div>
        <div className="w-full bg-white/20 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-8 mb-6">
        <h2 className="text-2xl font-bold text-white mb-6">{currentQ.question}</h2>

        <div className="space-y-3">
          {currentQ.options.map((option, index) => {
            let buttonClass = "w-full text-left p-4 rounded-lg transition-all duration-200 border-2 ";
            
            if (showFeedback) {
              if (index === currentQ.correctAnswer) {
                buttonClass += "bg-green-500/20 border-green-500 text-green-100";
              } else if (index === selectedAnswer && index !== currentQ.correctAnswer) {
                buttonClass += "bg-red-500/20 border-red-500 text-red-100";
              } else {
                buttonClass += "bg-white/5 border-white/20 text-gray-300";
              }
            } else {
              buttonClass += "bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-blue-400 cursor-pointer";
            }

            return (
              <button
                key={index}
                onClick={() => !showFeedback && handleAnswer(index)}
                disabled={showFeedback}
                className={buttonClass}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{option}</span>
                  {showFeedback && index === currentQ.correctAnswer && (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  )}
                  {showFeedback && index === selectedAnswer && index !== currentQ.correctAnswer && (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {showFeedback && currentQ.explanation && (
          <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <h4 className="text-blue-300 font-semibold mb-2">Explanation:</h4>
            <p className="text-blue-100">{currentQ.explanation}</p>
          </div>
        )}
      </div>

      {/* Score Display */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2">
          <span className="text-blue-200">Current Score:</span>
          <span className="text-white font-bold">{score}/{currentQuestion + (showFeedback ? 1 : 0)}</span>
        </div>
      </div>
    </div>
  );
};

export default QuizInterface;